export interface Group {
    id: number;
    name: string;
    channels: string[];
    banned: string[];
    admins: string[];
}