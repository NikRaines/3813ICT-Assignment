export interface Message {
    groupID: number;
    sender: string;
    channel: string;
    text: string;
}
