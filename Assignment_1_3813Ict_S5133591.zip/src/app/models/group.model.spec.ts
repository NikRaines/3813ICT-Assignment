import { Group } from './groupmodel';

describe('Group', () => {
  it('should create an instance', () => {
    expect(new Group()).toBeTruthy();
  });
});
