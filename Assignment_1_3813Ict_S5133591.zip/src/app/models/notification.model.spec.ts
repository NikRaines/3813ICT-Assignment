import { Notification } from './notificationmodel';

describe('Notification', () => {
  it('should create an instance', () => {
    expect(new Notification()).toBeTruthy();
  });
});
