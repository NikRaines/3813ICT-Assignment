export interface Notification {
	createdBy: string;
	description: string;
	reason: string;
}
