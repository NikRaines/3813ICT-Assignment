import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { Notification } from '../models/notification.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {  
  private apiUrl = 'http://localhost:3000';
  constructor(private http: HttpClient) {}

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/api/users`);
  }
  
  register(username: string, email: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/users/register`, { username, email, password });
  }

  // User Management
  approveUser(username: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/users/approve`, { username });
  }
  
  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.apiUrl}/api/notifications`);
  }

  updateUserRoles(username: string, role: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/users/updateRoles`, { username, role });
  }
  
  deleteUser(username: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/api/users/${username}`);
  }

  //Group Management
  updateUserGroups(username: string, groups: number[]): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/users/updateGroups`, { username, groups });
  }

  updateUserAppliedGroups(username: string, appliedGroups: number[]): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/users/updateAppliedGroups`, { username, appliedGroups });
  }

  banUserFromGroup(username: string, groupId: number, description: string, reason: string, bannedBy: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/groups/${groupId}/ban`, { username, description, reason, bannedBy});
  }
}
